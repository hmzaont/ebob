public class Ebob {

	public static void main(String[] args) {
		int a = ebob (5,15);
		System.out.println(a);
	}
	
	static int ebob (int enk,int enb) {
		int obeb=1;
		for(int i=enk; i>=1; i--) {
			if((enk % i == 0)&&(enb % i == 0)) {
				obeb=i;
				break;
			}
		}
		return obeb;
		
	}
}